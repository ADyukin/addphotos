# Photo Gallery Application

## Overview

This is a Flask-based photo management web application designed for mobile-first usage. The application features a modern, light-themed interface optimized for product photo documentation. Users can upload photos by selecting from device gallery or capturing directly with camera. The interface is organized into photo sections (main product, defects, additional) with visual placeholder grids for intuitive photo organization.

## System Architecture

The application follows a traditional Flask MVC (Model-View-Controller) architecture:

- **Frontend**: Bootstrap-based responsive UI with custom CSS and JavaScript
- **Backend**: Flask web framework with SQLAlchemy ORM
- **Database**: SQLite (default) with configurable database support via environment variables
- **File Storage**: Local filesystem storage in an `uploads` directory
- **Image Processing**: PIL (Python Imaging Library) for image optimization

## Key Components

### Backend Components

1. **app.py**: Main application factory and configuration
   - Configures Flask app with security settings
   - Sets up database connection with SQLAlchemy
   - Manages file upload settings (16MB max, specific file types)
   - Creates upload directory structure

2. **models.py**: Data models using SQLAlchemy ORM
   - `Photo` model with metadata (filename, size, mime type, upload date)
   - JSON serialization methods for API responses

3. **routes.py**: HTTP request handlers and business logic
   - File upload endpoint with validation and processing
   - Gallery view with photo listing
   - File serving for uploaded images
   - Utility functions for file handling

4. **main.py**: Application entry point for development server

### Frontend Components

1. **Templates**: Jinja2 HTML templates with Bootstrap styling
   - `index.html`: Upload interface with drag-and-drop
   - `gallery.html`: Photo gallery grid view

2. **Static Assets**:
   - `custom.css`: Custom styling for gallery and upload interface
   - `upload.js`: JavaScript for drag-and-drop functionality and file handling

## Data Flow

1. **Upload Process**:
   - User selects files, drags files to upload area, or captures photos with camera
   - Camera functionality uses WebRTC getUserMedia API for real-time video capture
   - JavaScript validates files client-side
   - Files are sent to `/upload` endpoint via AJAX
   - Server validates file type and size
   - Unique filename generated using UUID
   - Image processed and saved to uploads directory
   - Photo metadata stored in database

2. **Gallery Display**:
   - Photos retrieved from database ordered by upload date
   - Thumbnails displayed in responsive grid
   - File information shown with human-readable sizes

## External Dependencies

### Python Packages
- **Flask**: Web framework
- **Flask-SQLAlchemy**: Database ORM
- **Pillow (PIL)**: Image processing
- **Werkzeug**: WSGI utilities and file handling

### Frontend Libraries
- **Bootstrap 5**: UI framework with dark theme
- **Font Awesome**: Icon library
- **WebRTC getUserMedia API**: Camera access for photo capture
- **HTML5 Canvas**: Image processing and capture
- **Custom CSS/JS**: Enhanced user experience with camera functionality

## Deployment Strategy

The application is configured for flexible deployment:

- **Development**: Uses SQLite database and local file storage
- **Production**: Configurable via environment variables
  - `DATABASE_URL`: Database connection string
  - `SESSION_SECRET`: Security key for sessions
- **WSGI**: ProxyFix middleware for deployment behind reverse proxies
- **File Uploads**: Local storage with configurable upload directory

### Environment Configuration
- Default SQLite database (`photo_gallery.db`)
- Configurable database via `DATABASE_URL` environment variable
- Session security via `SESSION_SECRET` environment variable
- Pool management with connection recycling and health checks

## Changelog

```
Changelog:
- July 04, 2025. Initial setup
- July 04, 2025. Added camera capture functionality with WebRTC API
- July 04, 2025. Enhanced camera to support multiple photo capture with counter and improved error handling
- July 04, 2025. Complete redesign to mobile-first interface with photo sections and placeholder grids
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```